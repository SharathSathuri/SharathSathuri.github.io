# Sharath Sathuri — Portfolio

Vite + React 19 + TypeScript + Tailwind CSS + Framer Motion.

## Run locally
```
npm install
npm run dev
```

## Build
```
npm run build
```
Output goes to `dist/`.

## Deploy to Vercel
```
npx vercel --prod
```
Or connect the repo in the Vercel dashboard — it auto-detects Vite.
Framework preset: Vite. Build command: `npm run build`. Output dir: `dist`.

## Known placeholders to replace before going fully live
- **Hero visual**: currently an animated gradient mesh + empty avatar circle (`src/components/Hero.tsx`). Swap in a real photo when available.
- **OG image**: `index.html` references `/og-image.png` — add a 1200x630 image to `/public`.
- **Sarthie**: `src/data/content.ts` → `project` object has no public link/metrics, written conservatively as "early stage." Update once there's a link or real numbers.
- **Domain**: `index.html` canonical/OG URLs point to `sharathsathuri.com` — update to whatever domain is actually used.

## Content source
All copy is derived from the uploaded resume (`src/data/content.ts` is the single source of truth — edit there to update copy across the site).
