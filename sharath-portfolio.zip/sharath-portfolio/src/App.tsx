import { Navbar } from './components/Navbar'
import { Hero } from './components/Hero'
import { About } from './components/About'
import { Journey } from './components/Journey'
import { Leadership } from './components/Leadership'
import { Contact } from './components/Contact'

function App() {
  return (
    <div className="bg-ink min-h-screen font-body" style={{ color: '#F2EFE6' }}>
      <Navbar />
      <Hero />
      <About />
      <Journey />
      <Leadership />
      <Contact />
    </div>
  )
}

export default App
