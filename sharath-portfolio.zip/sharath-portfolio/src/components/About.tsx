import { WordsPullUpMultiStyle } from './PullUpText'
import { ScrollRevealText } from './ScrollRevealText'

export function About() {
  return (
    <section id="about" className="py-20 sm:py-28 md:py-32 px-4 md:px-6" style={{ backgroundColor: 'var(--bg)' }}>
      <div
        className="max-w-5xl mx-auto rounded-2xl md:rounded-[2rem] px-6 sm:px-10 md:px-16 py-14 sm:py-20 md:py-24 text-center"
        style={{ backgroundColor: 'var(--bg-card)' }}
      >
        <p className="rx-label rx-label-center mb-6">About</p>

        {/* w-full ensures the inline-flex inside wraps correctly at all viewports */}
        <h2 className="w-full text-3xl sm:text-4xl md:text-5xl lg:text-6xl max-w-3xl mx-auto leading-[0.95] sm:leading-[0.9] mb-8 sm:mb-10">
          <WordsPullUpMultiStyle
            segments={[
              { text: "I'm Sharath,", className: 'font-display font-normal' },
              { text: 'a pharmacist who started building instead.', className: 'font-display italic font-normal c-accent' },
              { text: 'Now I work where healthcare, strategy, and brand overlap.', className: 'font-display font-normal' },
            ]}
          />
        </h2>

        <ScrollRevealText
          text="Most people pick a lane. I collect them. From leading campus initiatives at IIT Jodhpur to building digital strategies for hospital expansions, from market research to working directly under Managing Directors — I've never waited for a title to start doing the work. I'm just getting started."
          className="text-sm sm:text-base md:text-lg leading-relaxed max-w-2xl mx-auto"
        />
      </div>
    </section>
  )
}
