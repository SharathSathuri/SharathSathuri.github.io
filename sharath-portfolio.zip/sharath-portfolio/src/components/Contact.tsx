import { Mail, Link2, Phone, ArrowUpRight } from 'lucide-react'
import { WordsPullUp } from './PullUpText'
import { profile } from '../data/content'

export function Contact() {
  return (
    <section id="contact" className="px-4 md:px-6 pb-4 md:pb-6" style={{ backgroundColor: 'var(--bg)' }}>
      <div
        className="rounded-2xl md:rounded-[2rem] px-6 sm:px-10 md:px-16 py-16 sm:py-20 md:py-24 text-center relative overflow-hidden"
        style={{ backgroundColor: 'var(--bg-card)' }}
      >
        <div className="absolute inset-0 bg-noise opacity-[0.08] pointer-events-none" />
        <div className="relative">
          <p className="rx-label rx-label-center mb-6">Get in touch</p>

          <h2 className="font-display text-3xl sm:text-5xl md:text-6xl leading-[0.95] mb-6" style={{ color: 'var(--fg)' }}>
            <WordsPullUp text="Let's build something." className="justify-center" />
          </h2>

          <p className="text-sm sm:text-base max-w-md mx-auto mb-10" style={{ color: 'var(--fg-dim)' }}>
            Open to roles and conversations in strategy, marketing, and healthcare operations.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-4">
            <a
              href={`mailto:${profile.email}`}
              className="group inline-flex items-center gap-2 font-medium px-5 py-2.5 rounded-full text-sm transition-all"
              style={{ backgroundColor: 'var(--accent)', color: 'var(--bg)' }}
              onMouseEnter={(e) => { e.currentTarget.style.opacity = '0.85' }}
              onMouseLeave={(e) => { e.currentTarget.style.opacity = '1' }}
            >
              <Mail size={15} />
              {profile.email}
            </a>
            <a
              href={profile.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              className="group inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm transition-colors"
              style={{ border: '1px solid var(--border)', color: 'var(--fg)' }}
              onMouseEnter={(e) => { e.currentTarget.style.borderColor = 'var(--sage)' }}
              onMouseLeave={(e) => { e.currentTarget.style.borderColor = 'var(--border)' }}
            >
              <Link2 size={15} />
              LinkedIn
              <ArrowUpRight size={13} style={{ opacity: 0.5 }} />
            </a>
            <a
              href={`tel:${profile.phone}`}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full text-sm transition-colors"
              style={{ border: '1px solid var(--border)', color: 'var(--fg)' }}
              onMouseEnter={(e) => { e.currentTarget.style.borderColor = 'var(--sage)' }}
              onMouseLeave={(e) => { e.currentTarget.style.borderColor = 'var(--border)' }}
            >
              <Phone size={15} />
              {profile.phone}
            </a>
          </div>
        </div>
      </div>

      <div
        className="flex flex-col sm:flex-row items-center justify-between gap-2 py-6 text-xs font-mono px-2"
        style={{ color: 'var(--fg-mute)' }}
      >
        <span>© {new Date().getFullYear()} {profile.fullName}</span>
        <span>{profile.location}</span>
      </div>
    </section>
  )
}
