import { motion } from 'framer-motion'
import { ArrowRight, User } from 'lucide-react'
import { WordsPullUp } from './PullUpText'

export function Hero() {
  return (
    <section id="top" className="relative h-screen p-3 sm:p-4 md:p-6">
      <div className="relative h-full w-full rounded-2xl md:rounded-[2rem] overflow-hidden" style={{ backgroundColor: 'var(--bg-card)' }}>

        {/* Animated gradient mesh */}
        <div className="absolute inset-0 overflow-hidden">
          <motion.div
            className="absolute -inset-[20%]"
            style={{
              background:
                'radial-gradient(circle at 20% 20%, rgba(122,140,126,0.3), transparent 50%), radial-gradient(circle at 80% 30%, rgba(201,167,124,0.22), transparent 50%), radial-gradient(circle at 50% 80%, rgba(122,140,126,0.18), transparent 55%)',
            }}
            animate={{ rotate: 360 }}
            transition={{ duration: 90, repeat: Infinity, ease: 'linear' }}
          />
        </div>

        <div className="noise-overlay absolute inset-0 mix-blend-overlay pointer-events-none" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/65" />

        {/* Content — stacked on mobile, side-by-side on lg+ */}
        <div className="absolute inset-0 flex flex-col justify-end p-5 sm:p-8 md:p-12 lg:p-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 lg:gap-8 items-end w-full">

            {/* Name block */}
            <div className="lg:col-span-8 min-w-0">
              <p className="rx-label mb-3 sm:mb-4">MBA Candidate · IIT Jodhpur</p>
              <h1 className="font-display font-medium leading-[0.9] tracking-[-0.02em] text-[11vw] sm:text-[9vw] md:text-[7.5vw] lg:text-[5.8vw] break-words" style={{ color: '#F2EFE6' }}>
                <WordsPullUp text="Sharath Sathuri" />
              </h1>
            </div>

            {/* Supporting text + CTA */}
            <div className="lg:col-span-4 flex flex-col gap-4 sm:gap-5">
              {/* Photo placeholder — hidden on mobile to avoid clutter */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
                className="hidden lg:flex w-16 h-16 rounded-full items-center justify-center self-start"
                style={{ border: '1px solid rgba(242,239,230,0.2)', backgroundColor: 'rgba(22,26,23,0.6)' }}
              >
                <User size={24} style={{ color: 'rgba(242,239,230,0.35)' }} />
              </motion.div>

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.5, ease: [0.16, 1, 0.3, 1] }}
                className="text-xs sm:text-sm md:text-base leading-relaxed"
                style={{ color: 'rgba(242,239,230,0.72)' }}
              >
                Product-minded strategist trained as a pharmacist — now working
                across healthcare operations, digital marketing, and an MBA at
                IIT Jodhpur.
              </motion.p>

              <motion.a
                href="#about"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.65, ease: [0.16, 1, 0.3, 1] }}
                className="group inline-flex items-center gap-2 rounded-full pl-5 pr-1.5 py-1.5 w-fit transition-all hover:gap-3"
                style={{ backgroundColor: 'var(--accent)' }}
              >
                <span className="font-medium text-sm sm:text-base" style={{ color: 'var(--bg)' }}>See the journey</span>
                <span
                  className="flex items-center justify-center rounded-full w-8 h-8 sm:w-9 sm:h-9 group-hover:scale-110 transition-transform"
                  style={{ backgroundColor: 'var(--bg)' }}
                >
                  <ArrowRight size={15} style={{ color: '#F2EFE6' }} />
                </span>
              </motion.a>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
