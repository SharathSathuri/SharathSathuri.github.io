import { useRef } from 'react'
import { motion, useInView } from 'framer-motion'
import { WordsPullUpMultiStyle } from './PullUpText'
import { experience } from '../data/content'

function TimelineCard({ item, index }: { item: (typeof experience)[number]; index: number }) {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: '-80px' })

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, scale: 0.97, y: 16 }}
      animate={inView ? { opacity: 1, scale: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay: index * 0.12, ease: [0.22, 1, 0.36, 1] }}
      className="relative rounded-2xl p-6 sm:p-7 flex flex-col gap-4 h-full"
      style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border)' }}
    >
      {/* Header row */}
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div className="min-w-0">
          <h3 className="font-display text-lg sm:text-xl" style={{ color: 'var(--fg)' }}>{item.role}</h3>
          <p className="text-sm mt-0.5" style={{ color: 'var(--accent)' }}>{item.org}</p>
        </div>
        {item.tag && (
          <span
            className="text-[10px] font-mono tracking-widest uppercase px-2.5 py-1 rounded-full shrink-0"
            style={{ backgroundColor: 'var(--bg-cardlt)', color: 'var(--accent)', border: '1px solid var(--border)' }}
          >
            {item.tag}
          </span>
        )}
      </div>

      {/* Meta */}
      <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs font-mono" style={{ color: 'var(--fg-mute)' }}>
        <span>{item.period}</span>
        <span className="w-1 h-1 rounded-full" style={{ backgroundColor: 'var(--fg-mute)' }} />
        <span>{item.location}</span>
      </div>

      {/* Bullet points */}
      <ul className="flex flex-col gap-2.5 mt-1 flex-1">
        {item.points.map((point, i) => (
          <li key={i} className="text-sm leading-relaxed pl-4 relative" style={{ color: 'var(--fg-dim)' }}>
            <span
              className="absolute left-0 top-[0.55em] w-1.5 h-1.5 rounded-full"
              style={{ backgroundColor: 'var(--sage)' }}
            />
            {point}
          </li>
        ))}
      </ul>
    </motion.div>
  )
}

export function Journey() {
  return (
    <section id="journey" className="min-h-screen py-20 sm:py-28 px-4 md:px-6 relative" style={{ backgroundColor: 'var(--bg)' }}>
      <div className="absolute inset-0 bg-noise opacity-[0.08] pointer-events-none" />
      <div className="relative max-w-6xl mx-auto">
        <p className="rx-label mb-5">Experience</p>
        <h2 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-normal mb-3 max-w-2xl">
          <WordsPullUpMultiStyle
            containerClassName="!justify-start"
            segments={[{ text: 'From the dispensing counter to the boardroom.', className: 'font-display' }]}
          />
        </h2>
        <p className="text-sm sm:text-base mb-12 sm:mb-16 max-w-xl" style={{ color: 'var(--fg-dim)' }}>
          Each role added a different lens — clinical precision, brand strategy, and now hospital-level operations.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {experience.map((item, i) => (
            <TimelineCard key={item.org + item.period} item={item} index={i} />
          ))}
        </div>
      </div>
    </section>
  )
}
