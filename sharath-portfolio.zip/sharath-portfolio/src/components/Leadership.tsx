import { useRef } from 'react'
import { motion, useInView } from 'framer-motion'
import { WordsPullUpMultiStyle } from './PullUpText'
import { leadership, education, academicWork, achievements, skills, interests, certifications } from '../data/content'

function FadeIn({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: '-60px' })
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 14 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  )
}

export function Leadership() {
  return (
    <section id="leadership" className="py-20 sm:py-28 px-4 md:px-6" style={{ backgroundColor: 'var(--bg)' }}>
      <div className="max-w-5xl mx-auto">
        <p className="rx-label mb-5">Background</p>
        <h2 className="text-2xl sm:text-3xl mb-12 sm:mb-16">
          <WordsPullUpMultiStyle
            containerClassName="!justify-start"
            segments={[{ text: 'Roles I chose to take on.', className: 'font-display' }]}
          />
        </h2>

        {/* ── Two-col grid: leadership+achievements LEFT, education+certs+skills RIGHT ── */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-start">

          {/* LEFT column */}
          <div className="flex flex-col gap-10">

            {/* Leadership */}
            <div>
              <p className="rx-label mb-5">Leadership</p>
              <div className="flex flex-col gap-5">
                {leadership.map((item, i) => (
                  <FadeIn key={item.role} delay={i * 0.1}>
                    <div
                      className="pl-4 py-1"
                      style={{ borderLeft: '2px solid var(--border)' }}
                    >
                      <p className="font-medium text-sm sm:text-base" style={{ color: 'var(--fg)' }}>{item.role}</p>
                      <p className="text-xs sm:text-sm mt-0.5" style={{ color: 'var(--fg-dim)' }}>{item.org}</p>
                      <p className="text-xs font-mono mt-1" style={{ color: 'var(--fg-mute)' }}>{item.period}</p>
                    </div>
                  </FadeIn>
                ))}
              </div>
            </div>

            {/* Recognition */}
            <div>
              <p className="rx-label mb-4">Recognition</p>
              <ul className="flex flex-col gap-2.5">
                {achievements.map((a) => (
                  <li key={a} className="text-sm leading-relaxed pl-4 relative" style={{ color: 'var(--fg-dim)' }}>
                    <span
                      className="absolute left-0 top-[0.55em] w-1.5 h-1.5 rounded-full"
                      style={{ backgroundColor: 'var(--accent)' }}
                    />
                    {a}
                  </li>
                ))}
              </ul>
            </div>

            {/* Skills & interests */}
            <div>
              <p className="rx-label mb-4">Skills & interests</p>
              <div className="flex flex-wrap gap-2">
                {[...skills.craft, ...interests].map((s) => (
                  <span
                    key={s}
                    className="text-xs px-3 py-1.5 rounded-full transition-colors"
                    style={{
                      border: '1px solid var(--border)',
                      color: 'var(--fg-mute)',
                    }}
                  >
                    {s}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* RIGHT column */}
          <div className="flex flex-col gap-10">

            {/* Education */}
            <div>
              <p className="rx-label mb-5">Education</p>
              <div className="flex flex-col gap-4">
                {education.map((edu, i) => (
                  <FadeIn key={edu.degree} delay={i * 0.08}>
                    <div
                      className="rounded-xl p-5 transition-colors"
                      style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border)' }}
                    >
                      <div className="flex items-start justify-between gap-3 flex-wrap">
                        <p className="font-medium text-sm sm:text-base leading-snug" style={{ color: 'var(--fg)' }}>
                          {edu.degree}
                        </p>
                        {edu.score && (
                          <span className="text-xs font-mono shrink-0" style={{ color: 'var(--accent)' }}>
                            {edu.score}
                          </span>
                        )}
                      </div>
                      <p className="text-xs sm:text-sm mt-1" style={{ color: 'var(--fg-dim)' }}>{edu.institute}</p>
                      {edu.sub && <p className="text-xs mt-0.5" style={{ color: 'var(--fg-mute)' }}>{edu.sub}</p>}
                      <p className="text-xs font-mono mt-2" style={{ color: 'var(--fg-mute)' }}>{edu.years}</p>
                    </div>
                  </FadeIn>
                ))}
              </div>
            </div>

            {/* Certifications */}
            <div>
              <p className="rx-label mb-4">Certifications</p>
              <div className="flex flex-col gap-3">
                {certifications.map((c) => (
                  <FadeIn key={c.title}>
                    <div
                      className="rounded-xl p-4"
                      style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border)' }}
                    >
                      <p className="text-sm font-medium" style={{ color: 'var(--fg)' }}>{c.title}</p>
                      <p className="text-xs mt-1" style={{ color: 'var(--fg-mute)' }}>{c.issuer}</p>
                    </div>
                  </FadeIn>
                ))}
              </div>
            </div>

            {/* Academic work */}
            <div>
              <p className="rx-label mb-4">Academic work</p>
              <div className="flex flex-col gap-4">
                {academicWork.map((w) => (
                  <div key={w.title}>
                    <p className="text-sm leading-snug" style={{ color: 'var(--fg)' }}>{w.title}</p>
                    <p className="text-xs mt-1 leading-relaxed" style={{ color: 'var(--fg-dim)' }}>{w.type}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
