import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Menu, X } from 'lucide-react'
import { ThemeToggle } from './ThemeToggle'
import { navItems } from '../data/content'

export function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <motion.nav
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
      className="fixed top-0 left-0 right-0 z-50 flex justify-center px-4 pt-3"
    >
      <div
        className="flex items-center justify-between gap-4 rounded-full px-4 sm:px-6 py-2.5 w-full max-w-3xl transition-all duration-300"
        style={{
          backgroundColor: scrolled ? 'var(--bg-card)' : 'var(--bg)',
          border: '1px solid var(--border)',
          backdropFilter: 'blur(12px)',
        }}
      >
        {/* Logo */}
        <a
          href="#top"
          className="font-display text-sm sm:text-base tracking-tight shrink-0"
          style={{ color: 'var(--fg)' }}
        >
          Sharath<span style={{ color: 'var(--accent)' }}>.</span>
        </a>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center gap-6 lg:gap-8">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="text-xs lg:text-sm transition-colors"
              style={{ color: 'var(--fg-sub)' }}
              onMouseEnter={(e) => (e.currentTarget.style.color = 'var(--fg)')}
              onMouseLeave={(e) => (e.currentTarget.style.color = 'var(--fg-sub)')}
            >
              {item.label}
            </a>
          ))}
        </div>

        {/* Right controls */}
        <div className="flex items-center gap-3">
          <ThemeToggle />
          <a
            href="#contact"
            className="hidden md:inline-flex items-center text-xs lg:text-sm font-medium px-4 py-1.5 rounded-full transition-all"
            style={{
              backgroundColor: 'var(--accent)',
              color: 'var(--bg)',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = 'var(--fg)'
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'var(--accent)'
            }}
          >
            Let's talk
          </a>
          <button
            className="md:hidden"
            style={{ color: 'var(--fg)' }}
            onClick={() => setOpen(!open)}
            aria-label={open ? 'Close menu' : 'Open menu'}
          >
            {open ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>

      {/* Mobile drawer */}
      {open && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="absolute top-16 w-[90%] max-w-sm rounded-2xl p-4 flex flex-col gap-3 md:hidden"
          style={{
            backgroundColor: 'var(--bg-card)',
            border: '1px solid var(--border)',
          }}
        >
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={() => setOpen(false)}
              className="text-sm py-1.5 transition-colors"
              style={{ color: 'var(--fg-sub)' }}
            >
              {item.label}
            </a>
          ))}
          <a
            href="#contact"
            onClick={() => setOpen(false)}
            className="text-sm font-medium px-4 py-2 rounded-full text-center mt-1 transition-colors"
            style={{ backgroundColor: 'var(--accent)', color: 'var(--bg)' }}
          >
            Let's talk
          </a>
        </motion.div>
      )}
    </motion.nav>
  )
}
