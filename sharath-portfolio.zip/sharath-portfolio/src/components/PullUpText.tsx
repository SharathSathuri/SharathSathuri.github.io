import { useRef } from 'react'
import { motion, useInView } from 'framer-motion'

interface WordsPullUpProps {
  text: string
  className?: string
  delayOffset?: number
}

export function WordsPullUp({ text, className = '', delayOffset = 0 }: WordsPullUpProps) {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: '-80px' })
  const words = text.split(' ')

  return (
    // Use inline-flex + flex-wrap so it wraps naturally on small screens
    <span ref={ref} className={`inline-flex flex-wrap gap-x-[0.28em] ${className}`}>
      {words.map((word, i) => (
        <span key={i} className="overflow-hidden inline-block">
          <motion.span
            className="inline-block"
            initial={{ y: '110%', opacity: 0 }}
            animate={inView ? { y: '0%', opacity: 1 } : {}}
            transition={{
              duration: 0.7,
              delay: delayOffset + i * 0.08,
              ease: [0.16, 1, 0.3, 1],
            }}
          >
            {word}
          </motion.span>
        </span>
      ))}
    </span>
  )
}

interface Segment {
  text: string
  className?: string
}

export function WordsPullUpMultiStyle({
  segments,
  containerClassName = '',
}: {
  segments: Segment[]
  containerClassName?: string
}) {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: '-80px' })

  let wordIndex = 0
  const allWords: { word: string; className: string; index: number }[] = []

  segments.forEach((segment) => {
    segment.text.split(' ').forEach((word) => {
      allWords.push({ word, className: segment.className || '', index: wordIndex++ })
    })
  })

  return (
    <span
      ref={ref}
      className={`inline-flex flex-wrap justify-center gap-x-[0.28em] w-full ${containerClassName}`}
    >
      {allWords.map(({ word, className, index }) => (
        <span key={index} className="overflow-hidden inline-block">
          <motion.span
            className={`inline-block ${className}`}
            style={{ color: className.includes('c-accent') ? 'var(--accent)' : 'var(--fg)' }}
            initial={{ y: '110%', opacity: 0 }}
            animate={inView ? { y: '0%', opacity: 1 } : {}}
            transition={{
              duration: 0.7,
              delay: index * 0.06,
              ease: [0.16, 1, 0.3, 1],
            }}
          >
            {word}
          </motion.span>
        </span>
      ))}
    </span>
  )
}
