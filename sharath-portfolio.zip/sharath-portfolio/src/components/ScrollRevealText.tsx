import { useRef } from 'react'
import { motion, useScroll, useTransform, MotionValue } from 'framer-motion'

function AnimatedChar({
  char,
  progress,
  range,
}: {
  char: string
  progress: MotionValue<number>
  range: [number, number]
}) {
  const opacity = useTransform(progress, range, [0.2, 1])
  return (
    <motion.span style={{ opacity, color: 'var(--fg)' }}>
      {char}
    </motion.span>
  )
}

export function ScrollRevealText({ text, className = '' }: { text: string; className?: string }) {
  const ref = useRef(null)
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start 0.8', 'end 0.3'],
  })

  const chars = text.split('')
  const total = chars.length

  return (
    <p ref={ref} className={className}>
      {chars.map((char, i) => {
        const charProgress = i / total
        const range: [number, number] = [
          Math.max(0, charProgress - 0.1),
          Math.min(1, charProgress + 0.05),
        ]
        return (
          <AnimatedChar
            key={i}
            char={char === ' ' ? '\u00A0' : char}
            progress={scrollYProgress}
            range={range}
          />
        )
      })}
    </p>
  )
}
