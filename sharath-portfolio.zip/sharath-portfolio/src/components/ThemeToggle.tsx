import { Sun, Moon } from 'lucide-react'
import { useTheme } from '../lib/ThemeContext'

export function ThemeToggle() {
  const { theme, toggle } = useTheme()

  return (
    <button
      onClick={toggle}
      aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
      className="theme-toggle flex items-center"
      title={theme === 'dark' ? 'Light mode' : 'Dark mode'}
    >
      <span className="theme-toggle-knob flex items-center justify-center">
        {theme === 'dark'
          ? <Moon size={9} style={{ color: '#0B0E0C' }} />
          : <Sun size={9} style={{ color: '#0B0E0C' }} />
        }
      </span>
    </button>
  )
}
