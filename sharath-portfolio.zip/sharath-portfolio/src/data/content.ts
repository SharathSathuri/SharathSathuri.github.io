// All content sourced from Sathuri Sharath Kumar Goud's resume (latest version).
// Items marked with a "placeholder" note are inferred/conservative — update with real specifics.

export const profile = {
  name: 'Sharath Sathuri',
  fullName: 'Sathuri Sharath Kumar Goud',
  rollNo: 'M25MSA068',
  phone: '+91-8639980996',
  email: 'sharathsathuri@gmail.com',
  iitEmail: 'm25msa068@iitj.ac.in',
  linkedin: 'https://linkedin.com/in/sharathsathuri',
  location: 'Jodhpur, Rajasthan, India',
  tagline: 'Builder, strategist, and recovering pharmacist.',
  positioning:
    'MBA candidate at IIT Jodhpur working across strategy, digital marketing, and operations. Trained as a pharmacist, which is why I default to evidence before opinion.',
}

export const education = [
  {
    degree: 'Masters of Business Administration (MBA)',
    institute: 'Indian Institute of Technology, Jodhpur',
    sub: 'School of Management and Entrepreneurship',
    years: '2025 – Present',
    score: null, // CGPA intentionally omitted from public site
  },
  {
    degree: 'B.Pharmacy',
    institute: 'G. Pulla Reddy College of Pharmacy, Osmania University',
    sub: null,
    years: '2020 – 2024',
    score: '8.58 CGPA',
  },
  {
    degree: 'Senior Secondary',
    institute: 'Narayana Junior College, TSBIE',
    sub: null,
    years: '2020',
    score: '93.4%',
  },
  {
    degree: 'Secondary',
    institute: 'Narayana Concept School, BSE',
    sub: null,
    years: '2018',
    score: '90%',
  },
]

export const experience = [
  {
    role: 'Management Trainee',
    org: 'Apex Hospitals',
    location: 'Jaipur, Rajasthan',
    period: 'May 2026 – Jul 2026',
    points: [
      'Worked directly under the Managing Director on strategic and operational initiatives, including org-wide KRA/KPI assessment for unit heads and department managers.',
      'Led digital launch strategy for the proposed Apex Agra facility — campaign planning, channel strategy, lead-generation framework, and a ₹1L/month budget allocation.',
      'Audited pharmacy, procurement, and supply chain functions; recommended workflow enhancements and coordinated vendor relations to support data-driven decisions.',
    ],
    tag: 'Most recent',
  },
  {
    role: 'Business Development Intern',
    org: 'Gulmahal Retail',
    location: 'Remote',
    period: 'Jan 2026 – Present',
    points: [
      'Run SWOT analysis and market research to shape business development strategy.',
      'Use Google Analytics insights to guide go-to-market and growth decisions.',
    ],
    tag: null,
  },
  {
    role: 'Marketing Intern',
    org: 'Huryo Labs',
    location: 'Remote',
    period: 'Oct 2025 – Dec 2025',
    points: [
      'Owned website content and branding optimisation across e-commerce and healthcare clients.',
      'Authored thought-leadership blogs and executed SWOT-based brand strategy.',
      'Planned and optimised bulk social content, video scripting, and AI-driven content workflows.',
      'Completed an advanced ChatGPT certification to speed up marketing production.',
    ],
    tag: null,
  },
  {
    role: 'Trainee',
    org: 'AG Pharmacy–NIMS',
    location: 'Hyderabad, India',
    period: 'Nov 2023 – Jan 2024',
    points: [
      'Handled prescriptions and counselled patients on dosage, side effects, and therapy compliance.',
      'Communicated directly with healthcare professionals during supervised clinical training.',
    ],
    tag: null,
  },
]

export const leadership = [
  {
    role: 'Secretary',
    org: 'Tech and Media Committee, IIT Jodhpur',
    period: '2025 – Present',
  },
  {
    role: 'Volunteer',
    org: 'V-Care Committee, IIT Jodhpur',
    period: '2025 – Present',
  },
  {
    role: 'President, Student Council',
    org: 'G. Pulla Reddy College of Pharmacy',
    period: '2023 – 2024',
  },
]

export const academicWork = [
  {
    title: 'Pharmacological Evaluation of Esculin on Paracetamol-Induced Hepatotoxicity Using Zebrafish Larvae',
    type: 'Research Project',
  },
  {
    title: 'Industrial Training, Stride Organics Pvt. Ltd.',
    type: 'GMP-compliant manufacturing, packaging, QC, AHU systems, water purification, and regulatory documentation for solid and liquid dosage forms.',
  },
]

export const certifications = [
  {
    title: 'Foundations of Project Management',
    issuer: 'Google, via Coursera',
  },
  {
    title: 'Advanced ChatGPT for Marketing',
    issuer: 'Completed during Huryo Labs internship',
  },
]

export const skills = {
  technical: ['Microsoft PowerPoint', 'Microsoft Word', 'Canva', 'Microsoft Excel'],
  craft: ['Relationship Building', 'Team Management', 'Organising Events', 'Adaptability', 'Attention to Detail'],
}

export const achievements = [
  '2nd Prize, Table Tennis Doubles — National Pharmacy Week 2023',
  '3rd Prize, IPA-C Gopalakrishna Murty National Pharma Quiz — IPA',
  'Consolidated Prize, National Level Pharmaceutics-I Video Making Competition',
]

export const interests = [
  'Table Tennis',
  'Visual Arts',
  'Cycling',
  'Music',
  'Film',
  'Vibe Coding',
]

export const navItems = [
  { label: 'About', href: '#about' },
  { label: 'Journey', href: '#journey' },
  { label: 'Leadership', href: '#leadership' },
  { label: 'Contact', href: '#contact' },
]
